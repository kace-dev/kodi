# -*- coding: utf-8 -*-
# serienstream.py - S.to Scraper for xship
# Rewritten 2026-02-06 for new s.to website structure (React/Laravel)

import re
from resources.lib.requestHandler import cRequestHandler
from scrapers.modules.tools import cParser
from scrapers.modules import cleantitle
from resources.lib.control import getSetting, urljoin

SITE_IDENTIFIER = 'serienstream'
SITE_DOMAIN = 's.to'
SITE_NAME = 'SerienStream'

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domain = getSetting('provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN)
        if not self.domain or self.domain.strip() == '':
            self.domain = SITE_DOMAIN
        self.base_link = 'https://' + self.domain
        self.series_link = self.base_link + '/serien'
        self.search_link = self.base_link + '/serien'  # s.to lists all series on /serien

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        """
        Search for streams on s.to.
        s.to is a series-only site, so we only handle season > 0.
        """
        sources = []
        try:
            if int(season) <= 0:
                return sources

            t = [cleantitle.get(i) for i in set(titles) if i]

            # Step 1: Find the series URL by searching in the full series listing
            seriesUrl = self._findSeries(titles, t)
            if not seriesUrl:
                return sources

            # Step 2: Navigate to the correct episode page
            episodeUrl = self._buildEpisodeUrl(seriesUrl, season, episode)
            if not episodeUrl:
                return sources

            # Step 3: Extract hoster links from the episode page
            sources = self._getHosters(episodeUrl)
            return sources

        except Exception as e:
            return sources

    def _findSeries(self, titles, cleanTitles):
        """Find the series URL by fetching the full series list from /serien"""
        try:
            oRequest = cRequestHandler(self.series_link, caching=True)
            oRequest.cacheTime = 60 * 60 * 24  # 24h cache
            sHtmlContent = oRequest.request()
            if not sHtmlContent:
                return None

            # New s.to structure: <a href="/serie/slug">Title</a>
            pattern = r'<a[^>]+href="(/serie/[^"]+)"[^>]*>\s*([^<]+?)\s*</a>'
            isMatch, aResult = cParser.parse(sHtmlContent, pattern)
            if not isMatch:
                return None

            for sUrl, sName in aResult:
                sName = sName.strip()
                cleanName = cleantitle.get(sName)
                for ct in cleanTitles:
                    if ct == cleanName:
                        if sUrl.startswith('/'):
                            sUrl = self.base_link + sUrl
                        return sUrl
            return None
        except:
            return None

    def _buildEpisodeUrl(self, seriesUrl, season, episode):
        """Build the direct episode URL using the new s.to URL scheme:
           /serie/slug/staffel-N/episode-M
        """
        try:
            # Ensure seriesUrl is clean (no trailing slash)
            seriesUrl = seriesUrl.rstrip('/')

            # New URL format: /serie/slug/staffel-N/episode-M
            episodeUrl = '%s/staffel-%s/episode-%s' % (seriesUrl, str(season), str(episode))
            return episodeUrl
        except:
            return None

    def _getHosters(self, episodeUrl):
        """Extract hoster links from an episode page.
        
        New s.to structure uses <button> elements with data attributes:
        - data-link-id="12345"
        - data-play-url="/r?t=encrypted_token"
        - data-provider-name="VOE"
        - data-language-id="1" (1=DE, 2=EN, 3=EN+DE sub)
        - data-language-label="Deutsch"
        """
        sources = []
        try:
            oRequest = cRequestHandler(episodeUrl, caching=False)
            sHtmlContent = oRequest.request()
            if not sHtmlContent:
                return sources

            # Parse the hoster buttons
            # Pattern: button with data-link-id, data-play-url, data-provider-name, data-language-id
            pattern = (
                r'<button[^>]*'
                r'data-link-id="(\d+)"[^>]*'
                r'data-play-url="([^"]+)"[^>]*'
                r'data-provider-name="([^"]+)"[^>]*'
                r'data-language-label="([^"]+)"[^>]*'
                r'data-language-id="(\d+)"'
            )
            isMatch, aResult = cParser.parse(sHtmlContent, pattern)

            if not isMatch:
                # Try alternative attribute order
                pattern2 = (
                    r'data-link-id="(\d+)"[^>]*'
                    r'data-play-url="([^"]+)"[^>]*'
                    r'(?:data-auto-embed="[^"]*"[^>]*)?'
                    r'data-provider-name="([^"]+)"[^>]*'
                    r'data-language-label="([^"]+)"[^>]*'
                    r'data-language-id="(\d+)"'
                )
                isMatch, aResult = cParser.parse(sHtmlContent, pattern2)

            if not isMatch:
                # Fallback: parse individual buttons more flexibly
                aResult = self._parseHostersFlexible(sHtmlContent)
                if not aResult:
                    return sources

            from resources.lib.utils import isBlockedHoster

            for item in aResult:
                try:
                    if len(item) >= 5:
                        linkId, playUrl, providerName, langLabel, langId = item[0], item[1], item[2], item[3], item[4]
                    elif len(item) >= 3:
                        linkId, playUrl, providerName = item[0], item[1], item[2]
                        langLabel = 'Deutsch'
                        langId = '1'
                    else:
                        continue

                    # Build the full redirect URL
                    if playUrl.startswith('/'):
                        fullUrl = self.base_link + playUrl
                    else:
                        fullUrl = playUrl

                    # Determine language
                    # 1=Deutsch, 2=Englisch, 3=Deutsch Untertitel
                    langId = str(langId)
                    if langId == '1':
                        language = 'de'
                    elif langId == '3':
                        language = 'de'  # German subtitles
                    else:
                        continue  # Skip non-German sources

                    hosterName = providerName.strip().lower()

                    # Resolve the redirect URL to get the actual hoster URL
                    resolvedUrl = self._resolveRedirect(fullUrl, episodeUrl)
                    if not resolvedUrl:
                        continue

                    isBlocked, sDomain, sUrl, prioHoster = isBlockedHoster(resolvedUrl)
                    if isBlocked:
                        continue

                    # s.to doesn't provide quality info per hoster, default to SD
                    # resolveUrl will determine actual quality during playback
                    quality = 'SD'

                    sources.append({
                        'source': hosterName,
                        'quality': quality,
                        'language': language,
                        'url': sUrl if sUrl else resolvedUrl,
                        'direct': True,
                        'prioHoster': prioHoster if prioHoster else 100
                    })
                except:
                    continue

            return sources
        except:
            return sources

    def _parseHostersFlexible(self, html):
        """Flexibly parse hoster info when strict pattern doesn't match"""
        results = []
        try:
            # Find all button blocks with data-link-id
            buttons = re.findall(
                r'<button[^>]*data-link-id="(\d+)"(.*?)(?:>|/>)',
                html, re.DOTALL
            )
            for linkId, attrs in buttons:
                playUrl = re.search(r'data-play-url="([^"]+)"', attrs)
                providerName = re.search(r'data-provider-name="([^"]+)"', attrs)
                langLabel = re.search(r'data-language-label="([^"]+)"', attrs)
                langId = re.search(r'data-language-id="(\d+)"', attrs)

                if playUrl and providerName:
                    results.append((
                        linkId,
                        playUrl.group(1),
                        providerName.group(1),
                        langLabel.group(1) if langLabel else 'Deutsch',
                        langId.group(1) if langId else '1'
                    ))
        except:
            pass
        return results if results else None

    def _resolveRedirect(self, url, referer=''):
        """Follow the s.to redirect to get the actual hoster URL.
        s.to now uses /r?t=encrypted_token which redirects to the hoster.
        """
        try:
            oRequest = cRequestHandler(url, caching=False)
            oRequest.addHeaderEntry('Referer', referer)
            oRequest.addHeaderEntry('Upgrade-Insecure-Requests', '1')
            oRequest.request()
            realUrl = oRequest.getRealUrl()
            if realUrl and self.domain not in realUrl:
                return realUrl
            return None
        except:
            return None

    def resolve(self, url):
        """Resolve a URL to a playable stream"""
        try:
            if 'voe' in url.lower():
                from resources.lib.control import urlparse as _urlparse
                parsed = _urlparse(url)
                sDomain = parsed.hostname
                if sDomain and 'voe' not in sDomain:
                    url = url.replace(sDomain, 'voe.sx')
            return url
        except:
            return url