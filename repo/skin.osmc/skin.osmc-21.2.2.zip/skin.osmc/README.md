# skin.osmc

The default skin for OSMC.

For further information, check out the wiki here: https://osmc.tv/wiki/general/the-osmc-skin/

## This skin is shipped with official releases of OSMC (https://osmc.tv/download/).

Follow these instructions to install the OSMC Skin on other platforms: https://osmcsk.in/

Original skin: Andy Morton (https://github.com/BobCratchett)

Original design: Simon Brunton (https://simonbrunton.com/)

Skinner: Julian Michel (https://github.com/Ch1llb0/skin.osmc)
